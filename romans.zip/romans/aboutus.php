<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <title>Roman's pizza</title>

        <meta name="keywords" content="free website templates, CSS layout, Pizza Company Website, HTML CSS" />

        <meta name="description" content="Pizza Company Website - free CSS website template, Free HTML CSS Layout" />

        <link href="templatemo_style.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            <!--
            .style1 {
                font-size: 16px;
                font-weight: bold;
            }
            -->
        </style>
    </head>
    <body>
        <div id="templatemo_container">
            <div id="templatemo_header_section"> </div>
            <div id="templatemo_menu_bg">
                <div id="templatemo_menu">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="aboutus.php"  class="current">About Us</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                        <li><a href="product.php">Product</a></li>
                        <li><a href="loginindex.php">Order Now! </a></li>
                        <li><a href="franchise.php">Franchise</a></li>
                    </ul>
                </div>
            </div>
            <div id="templatemo_header_pizza"> </div>
            <div id="templatemo_content">
                <div id="templatemo_content_left1">
                    <div class="text" style="color:#000000">
                        <div align="center" class="style1">THE PIZZA STORY</div>
                                
                        <div align="justify">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The pizza creator’s idea was to come up with an authentic thin crunchy Italiano pizza crust with flavours  that would suit the taste of the African people.<br />
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The first branch Romans's Pizza was opened in Gauteng, in December of 2011. It was an immediate success, five more branches were opened in 2012, to serve the thousands of pizza patriots who ordered their favorite pizza flavors.<br />
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Romans's Pizza has become a big challenge for all other international and local pizza brands operating in the South Africa.Romans's Pizza will soon be in your neighborhood to serve you the biggest & tasteful  Pizza in the Southern hemisphere.<br />

                        </div>
                        <div align="center" class="style1">WHY Romans's Pizza</div>
                        <div align="justify">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The special dough mix of the pizza is rolled right in front of the customer so they can see the entire process of the preparation. The best quality toppings are used to give the customer the famous original Romans's Pizza.<br />
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The affordable prices along with its quality flavours  have made the Romans's Pizza brand the success it is today.
                            It is undoubtedly the favorite  party food and the food habit of families and corporate business groups.<br />
                            Now Romans's Pizza will invade the other parts of the South Africa.<br />
                        </div>
                        <strong>
                            <div align="center">Take a “TASTE” bite of an EXCELLENT business opportunity</div></strong></div>

                </div>

            </div>

        </div>

        <div>
        </div>
    </body>

</html>