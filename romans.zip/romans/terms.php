<div style="width:300px; height:400px; color:#000000;">
  <div align="justify">
  <br ><strong>* 30 minutes guarantee applies to places within 300 meters away from or mama's Maria building.</strong></br>
    
   <br /><strong>*  Guarantee applies to a single receipt delivery transaction/maximmum of 4 pizzas.</strong></br>
    
    <br /><strong>* Guaranteed time maybe suspended depending on the weather conditions for the safety of our delivery riders.</strong></br>
    
   <br /><strong>* All prices quoted are in South African Rand. Price and availability information is subject to change without notice.</strong></br>
    
   <br /><strong>* Mode of payment are as follows:customers with Paypal account can pay through Paypal otherwise Cash on Delivery(COD).</strong></br>
  </div>
</div>
